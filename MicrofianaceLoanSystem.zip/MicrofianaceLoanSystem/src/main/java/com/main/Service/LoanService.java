package com.main.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.main.Repository.CustomerRepository;
import com.main.Repository.LoanRepository;
import com.main.model.Customer;
import com.main.model.Loan;
import com.main.model.LoanDTO;

@Service
public class LoanService
{
	@Autowired
	private LoanRepository loanRepository;


	@Autowired
	private CustomerRepository customerRepository;


	// EMI Calculation
	private double calculateEmi(double p, double r, int n) {
	double monthlyRate = r / (12 * 100);
	return (p * monthlyRate * Math.pow(1 + monthlyRate, n)) /
	(Math.pow(1 + monthlyRate, n) - 1);
	}


	// Apply Loan + Approval Logic
	public Loan applyLoan(Long customerId, LoanDTO dto) {
	Customer customer = customerRepository.findById(customerId)
	.orElseThrow(() -> new RuntimeException("Customer not found"));


	Loan loan = new Loan();
	loan.setAmount(dto.getAmount());
	loan.setTenureMonths(dto.getTenureMonths());
	loan.setInterestRate(dto.getInterestRate());


	double emi = calculateEmi(dto.getAmount(), dto.getInterestRate(), dto.getTenureMonths());
	loan.setEmi(emi);


	// Simple Approval Rule
	if (emi <= 5000) {
	loan.setStatus("APPROVED");
	} else {
	loan.setStatus("REJECTED");
	}


	loan.setCustomer(customer);
	return loanRepository.save(loan);
	}

}
