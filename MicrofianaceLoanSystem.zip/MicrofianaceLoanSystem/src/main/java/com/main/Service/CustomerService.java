package com.main.Service;

import org.springframework.beans.factory.annotation.Autowired;

import com.main.Repository.CustomerRepository;
import com.main.model.Customer;
import com.main.model.CustomerDTO;

public class CustomerService 
{
	@Autowired
	private CustomerRepository repository;


	public Customer createCustomer(CustomerDTO dto) {
	Customer c = new Customer();
	c.setName(dto.getName());
	c.setMobile(dto.getMobile());
	c.setAddress(dto.getAddress());
	return repository.save(c);
	}

}
