package com.main.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.main.Repository.CustomerRepository;
import com.main.model.Customer;

public class CustomerMvcController
{
	
	@Autowired
	private CustomerRepository customerRepository;


	// READ
	@GetMapping
	public String listCustomers(Model model) {
	model.addAttribute("customers", customerRepository.findAll());
	return "customer-list";
	}


	// CREATE FORM
	@GetMapping("/new")
	public String createForm(Model model) {
	model.addAttribute("customer", new Customer());
	return "customer-form";
	}


	// CREATE
	@PostMapping
	public String saveCustomer(@ModelAttribute Customer customer) {
	customerRepository.save(customer);
	return "redirect:/customers";
	}


	// UPDATE FORM
	@GetMapping("/edit/{id}")
	public String editForm(@PathVariable Long id, Model model) {
	model.addAttribute("customer", customerRepository.findById(id).get());
	return "customer-form";
	}


	// DELETE
	@GetMapping("/delete/{id}")
	public String deleteCustomer(@PathVariable Long id) {
	customerRepository.deleteById(id);
	return "redirect:/customers";
	}

}
