package com.main.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.main.Repository.LoanRepository;
import com.main.Service.CustomerService;
import com.main.Service.LoanService;
import com.main.model.Customer;
import com.main.model.CustomerDTO;
import com.main.model.Loan;
import com.main.model.LoanDTO;



@RestController
@RequestMapping("/api")
public class MicrofinanceControlle
{
	@Autowired
	private CustomerService customerService;


	@Autowired
	private LoanService loanService;


	@Autowired
	private LoanRepository loanRepository;


	// Create Customer
	@PostMapping("/customers")
	public Customer createCustomer(@RequestBody CustomerDTO dto) {
	return customerService.createCustomer(dto);
	}


	// Apply Loan
	@PostMapping("/customers/{id}/loan")
	public Loan applyLoan(@PathVariable Long id,@RequestBody LoanDTO dto) {
	return loanService.applyLoan(id, dto);
	}


	// View Loans
	@GetMapping("/customers/{id}/loans")
	public List<Loan> getLoans(@PathVariable Long id) {
	return loanRepository.findByCustomerId(id);
	}
	
}
