package com.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicrofianaceLoanSystem {

	public static void main(String[] args)
	{
		System.out.println("This is Hospital Crud Operation....");
		SpringApplication.run(MicrofianaceLoanSystem.class, args);
	}

}
