package com.main.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.main.model.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Long> 
{

}
