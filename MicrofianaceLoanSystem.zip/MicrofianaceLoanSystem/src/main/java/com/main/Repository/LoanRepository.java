package com.main.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.main.model.Loan;

public interface LoanRepository extends JpaRepository<Loan, Long>
{
	List<Loan> findByCustomerId(Long customerId);
}
