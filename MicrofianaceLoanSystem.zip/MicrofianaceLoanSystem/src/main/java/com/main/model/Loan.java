package com.main.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "loans")
public class Loan
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private double amount;
	private int tenureMonths;
	private double interestRate;
	private double emi;
	private String status; // APPLIED / APPROVED / REJECTED


	@ManyToOne
	@JoinColumn(name = "customer_id")
	private Customer customer;


	// getters & setters
	public Long getId() { return id; }
	public double getAmount() { return amount; }
	public void setAmount(double amount) { this.amount = amount; }
	public int getTenureMonths() { return tenureMonths; }
	public void setTenureMonths(int tenureMonths) { this.tenureMonths = tenureMonths; }
	public double getInterestRate() { return interestRate; }
	public void setInterestRate(double interestRate) { this.interestRate = interestRate; }
	public double getEmi() { return emi; }
	public void setEmi(double emi) { this.emi = emi; }
	public String getStatus() { return status; }
	public void setStatus(String status) { this.status = status; }
	public Customer getCustomer() { return customer; }
	public void setCustomer(Customer customer) { this.customer = customer; }

}
