package com.main.model;

public class LoanDTO 
{
	private double amount;

	private int tenureMonths;

	private double interestRate;


	// getters & setters
	public double getAmount() { return amount; }
	public void setAmount(double amount) { this.amount = amount; }
	public int getTenureMonths() { return tenureMonths; }
	public void setTenureMonths(int tenureMonths) { this.tenureMonths = tenureMonths; }
	public double getInterestRate() { return interestRate; }
	public void setInterestRate(double interestRate) { this.interestRate = interestRate; }
}
