<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Insert title here</title>
</head>
<body>

<h2>Customer Form</h2>
<form action="/customers" method="post">
<input type="hidden" name="id" value="${customer.id}"/>
Name: <input type="text" name="name" value="${customer.name}"/><br/>
Mobile: <input type="text" name="mobile" value="${customer.mobile}"/><br/>
Address: <input type="text" name="address" value="${customer.address}"/><br/>
<button type="submit">Save</button>
</form>



</body>
</html>