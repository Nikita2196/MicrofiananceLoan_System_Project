<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Insert title here</title>
</head>
<body>

<h2>Customer List</h2>
<a href="customers/new">Add Customer</a>
<table border="1">
<tr><th>ID</th><th>Name</th><th>Mobile</th><th>Address</th><th>Action</th></tr>
<c:forEach items="${customers}" var="c">
<tr>
<td>${c.id}</td>
<td>${c.name}</td>
<td>${c.mobile}</td>
<td>${c.address}</td>
<td>
<a href="customers/edit/${c.id}">Edit</a> |
<a href="customers/delete/${c.id}">Delete</a>
</td>
</tr>
</c:forEach>
</table>

</body>
</html>